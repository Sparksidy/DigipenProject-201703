Student Name:

Project Name:

What I implemented:

Directions (if needed):

What I liked about the project and framework:

What I disliked about the project and framework:

Any difficulties I experienced while doing the project:

Hours spent:

Agent Communication (file and line number):

New selector node (name):

New decorator nodes (names):

10 total nodes (names):

3 Behavior trees (names):

Extra credit: