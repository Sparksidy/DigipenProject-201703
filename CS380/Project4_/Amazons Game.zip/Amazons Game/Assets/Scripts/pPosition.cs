﻿using UnityEngine;
using System.Collections;

public class pPosition : MonoBehaviour
{
  public gridPos pos;

	// Use this for initialization
	void Start () {
    pos = new gridPos();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
