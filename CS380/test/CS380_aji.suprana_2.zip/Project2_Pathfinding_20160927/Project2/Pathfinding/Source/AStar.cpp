#include <Stdafx.h>

#define getCoordinate(argument1,argument2) g_terrain.GetCoordinates(argument2,argument1)
GarbageCollector* g_garbage = nullptr;

void Node::operator=(const Node & rhs)
{
  g = rhs.g;
  h = rhs.h;
  parent = rhs.parent;
}


AStar::AStar()
{
  g_garbage = new GarbageCollector;
}
AStar::~AStar()
{
  delete g_garbage;
}

void AStar::Init()
{
  if (initialized)
    return;

  //assign heuristic calculating method
  heuristicFn[0] = HeuristicEucledean;
  heuristicFn[1] = HeuristicOctile;
  heuristicFn[2] = HeuristicChebyshev;
  heuristicFn[3] = HeuristicManhattan;

  initialized = true;
}

void AStar::Reset(int x, int y,int endX, int endY)
{
  Init();

  if (x == endX && y == endY)
    return;

  g_garbage->Clear();
  openList.clear();

  start = g_garbage->Allocate(x, y);
  end = g_garbage->Allocate(endX, endY);


  *start = CalculateCost(nullptr, g_garbage->index(x, y));
  AddToOpenCloseList(x, y, NODE_OPEN);
  currentStep = 0;
  g_terrain.SetColor(y, x, DEBUG_COLOR_YELLOW);
}

Node AStar::CalculateCost(Node* parent, int idx)
{
  Node newNode;
  gridPos pos = g_garbage->GetGridPos(idx);
  if (parent)
  {
    //Distance vector from parent to current node
    Vec3 distVec = (getCoordinate(parent->x, parent->y) - getCoordinate(pos.x, pos.y));
    newNode.g = parent->g + D3DXVec3Length(&distVec);
  }
  else
  {
    newNode.g = 0;
  }

  newNode.parent = parent;
  newNode.h = heuristicFn[m_heuristicCalc](getCoordinate(pos.x, pos.y), getCoordinate(end->x, end->y)) * m_heuristicWeight;
  return newNode;
}

bool AStar::Step(std::list<D3DXVECTOR3>& waypoint)
{
  int maxStep;
  m_singleStep ? maxStep = 1 : maxStep = -1;
  currentStep = 0;
  while (currentStep < maxStep && openList.size() != 0)
  {
    currentStep++;
    Node* parent = nullptr;
    ////////////////////////////////////////////////////
    //pop cheapest node in open list
    ///////////////////////////////////////////////////
    float cheapest = std::numeric_limits<float>::infinity();
    for (auto it : openList)
    {
      //get the node data from the garbage collector
      Node* curNode = g_garbage->Get(it);

      //devensive coding to prevent nullptr operations
      Debug::DebugPrint(curNode == nullptr,"Step: Pop cheapest node, garbage array size : %d, error access index %d",g_garbage->size,it);
      
      //calculate current cost
      float currentCost = curNode->g + curNode->h;
      //replace cheapset node  if current cost is cheaper
      if (cheapest > currentCost)
      {
        cheapest = currentCost;
        parent = curNode;
      }
    }
    RemoveFromList(parent->x, parent->y);

    ////////////////////////////////////////////////////
    //If node is the goal node, Get path
    ///////////////////////////////////////////////////
    if (parent == end)
    {
      GetPath(parent, waypoint);
      return true;
    }

    ////////////////////////////////////////////////////
    //For all childs
    ///////////////////////////////////////////////////
    for (auto i : child)
    {
      gridPos pos = (*parent + i);

      //Check if out of range
      if (pos.x < 0 || pos.y < 0 || pos.x > g_garbage->size - 1 || pos.y > g_garbage->size - 1)
        continue;

      //Check if diagonals
      if (std::abs(i.x) == std::abs(i.y))
      {
        bool invalidMove = false;
        //it is diagonal, check top bot left right if is wall
        invalidMove |= g_terrain.IsWall(parent->y + i.y, parent->x);
        invalidMove |= g_terrain.IsWall(parent->y, parent->x + i.x);

        if (invalidMove)
          continue;
      }

      if (g_terrain.IsWall(pos.y, pos.x))
        continue;

      int childIndex = g_garbage->index(pos.x,pos.y);
      Node cost = CalculateCost(parent, childIndex);



      //if unallocated
      Node* node = g_garbage->Get(childIndex);

      //if it is not even allocated, allocate, push to openlist
      if (node == nullptr)
      {
        Node* newAllocate = g_garbage->Allocate(pos.x, pos.y);
        *newAllocate = cost;
        AddToOpenCloseList(pos.x, pos.y, NODE_OPEN);
        continue;
      }

      if (node->openClose == NODE_UNLISTED)
      {
        *node = cost;
        AddToOpenCloseList(pos.x, pos.y, NODE_OPEN);
      }
      else
      {
        if (cost.h + cost.g < node->g + node->h)
        {
          RemoveFromList(pos.x, pos.y);
          *node = cost;
          AddToOpenCloseList(pos.x, pos.y, NODE_OPEN);
        }
      }
    }
    ////////////////////////////////////////////////////
    //place parent node on closed list
    ///////////////////////////////////////////////////
    AddToOpenCloseList(parent->x, parent->y, NODE_CLOSE);
  }
  if (openList.size() == 0)
    return true;
  else
    return false;
}

bool AStar::StraightLineOptimize(std::list<D3DXVECTOR3>& waypoint)
{
  gridPos* s = start;
  gridPos* e = end;
  bool wallExist = false;
  int minX, maxX, minY, maxY;
  minX = min(start->x, end->x);
  maxX = max(start->x, end->x);
  minY = min(start->y, end->y);
  maxY = max(start->y, end->y);

  for (int x = minX; x <= maxX; x++)
  {
    for (int y = minY; y <= maxY; y++)
    {
      wallExist |= g_terrain.IsWall(y,x);
    }
  }

  if (!wallExist)
  {
    waypoint.clear();
    waypoint.push_back(g_terrain.GetCoordinates(s->y, s->x));
    waypoint.push_back(g_terrain.GetCoordinates(e->y, e->x));
    return true;
  }
  return false;
}

void AStar::RubberBanding(Node* end)
{
  Node* pp = end->parent->parent;
  Node* p = end->parent;
  Node* c = end;

  while (pp)
  {
    int minX, maxX, minY, maxY;
    bool wallExist = false;

    minX = min(pp->x, c->x);
    maxX = max(pp->x, c->x);
    minY = min(pp->y, c->y);
    maxY = max(pp->y, c->y);

    for (int x = minX; x <= maxX; x++)
    {
      for (int y = minY; y <= maxY; y++)
      {
        wallExist |= g_terrain.IsWall(y, x);
      }
    }

    if (!wallExist)
    {
      c->parent = pp;
    }
    else
    {
      c = p;
    }
    p = pp;
    pp = pp->parent;
  }
}

void AStar::Smoothing(std::list<D3DXVECTOR3>& l)
{
  std::list <Vec3> newList;
  typedef std::list<Vec3>::iterator listIterator;
  int i = 0;
  int listSize = l.size();
  for (listIterator it = l.begin(); it != l.end(); it++)
  {
    newList.push_back(*it);
    if (it == l.end())
      continue;

    if (i == listSize - 1)
    {
      break;
    }

    Vec3 p1, p2, p3, p4;
    listIterator copyit = it;
    if (i == 0)
    {
      p1 = *copyit;
      p2 = *copyit;
      p3 = *++copyit;
      p4 = *++copyit;
    }
    else if (i == listSize - 2)
    {
      p1 = *--copyit;
      p2 = *++copyit;
      p3 = *++copyit;
      p4 = *copyit;
    }
    else
    {
      p1 = *--copyit;
      p2 = *++copyit;
      p3 = *++copyit;
      p4 = *++copyit;
    }

    for (int i = 1; i <= 3; ++i)
    {
      float s = 0.25f * i;
      Vec3 newPoint;
      newPoint = p1 * (-0.5f * s * s * s    +           s * s    - 0.5f * s ) +
                 p2 * (1.5f  * s * s * s    + (-2.5f) * s * s    + 1.0f     ) +
                 p3 * (-1.5f * s * s * s    + 2       * s * s    + 0.5f * s ) +
                 p4 * (0.5f * s * s * s     - 0.5f    * s * s               );

      newList.push_back(newPoint);
    }

    ++i;
  }

  l = newList;
}

void AStar::GetPath(Node* end, std::list<D3DXVECTOR3>& l)
{
  if (m_rubberband)
  {
    RubberBanding(end);

  }

  Node* cur = end;
  l.clear();
  while (cur)
  {
    l.push_front(g_terrain.GetCoordinates(cur->y, cur->x));
    cur = cur->parent;
  }

  if (m_smooth)
  {
    Smoothing(l);
  }
}

void AStar::RemoveFromList(int x, int y)
{

  Node* addThis = g_garbage->Get(x, y);
  ////addThis != nullptr
  //Debug::DebugPrint(addThis == nullptr, "RemoveFromList: invalid x y index");
  ////current node is not part of open or close list
  //Debug::DebugPrint(addThis->openClose == NODE_UNLISTED,"RemoveFromList: doesnt exist in anylist");

  ///////////////////////
  //Removing From list
  //////////////////////
  if (addThis->openClose == NODE_OPEN)
    openList.erase(g_garbage->index(x, y));
  //else
  //  closeList.erase(g_garbage->index(x, y));

  //Changing current status
  addThis->openClose = NODE_UNLISTED;
  g_garbage->DumpOpenClose();
}

bool AStar::AddToOpenCloseList(int x, int y, NodeOpeClose stat)
{
  bool Error = false; 
  DebugDrawingColor color;
  std::unordered_set<int>* list = nullptr;
  stat == NODE_OPEN ? list = &openList : list = nullptr;
  stat == NODE_OPEN ? color = DEBUG_COLOR_BLUE : color = DEBUG_COLOR_YELLOW;
  //if (list)
  //{
  //  //Check this node existed in open/close list
  //  std::unordered_set<int>::iterator it;
  //  it = list->find(GarbageCollector::index(x, y));
  //  Debug::DebugPrint(Error = (it != list->end()), "AddToOpenCloseList: this node is already existed in List!");
  //  if (Error) return false;
  //}


  //Check if already added to any list
  Node* addThis = g_garbage->Get(x, y);
  Debug::DebugPrint(Error = (addThis == nullptr), "AddToOpenCloseList: Existed in list!");
  if(Error) return false;

  //Check if already added to any list
  Debug::DebugPrint(Error = (addThis->openClose == NODE_CLOSE || addThis->openClose == NODE_OPEN) , "AddToOpenCloseList: Existed in list!");
  if (Error) return false;
  
  g_terrain.SetColor(y, x, color);

  if(list)
    list->insert(GarbageCollector::index(x, y));

  addThis->openClose = stat;
  g_garbage->DumpOpenClose();
  return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
// GARBAGE COLLECTOR
////////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned GarbageCollector::size;

GarbageCollector::GarbageCollector()
{
  size = g_terrain.GetWidth();
  //size = 20 ;

  nodes = new Node[size * size];
  DumpMemory();
  for (int y = 0; y < size; ++y)
  {
    for (int x = 0; x < size; ++x)
    {
      nodes[index(x, y)].x = x;
      nodes[index(x, y)].y = y;
    }
  }
}

GarbageCollector::~GarbageCollector()
{
  delete [] nodes;
}

void GarbageCollector::Reset()
{
  size = g_terrain.GetWidth();
  delete [] nodes;
  nodes = new Node[size * size];
  DumpMemory();
  for (int y = 0; y < size; ++y)
  {
    for (int x = 0; x < size; ++x)
    {
      nodes[index(x, y)].x = x;
      nodes[index(x, y)].y = y;
    }
  }

}

void GarbageCollector::Clear()
{
  for (int i = 0; i < size * size; ++i)
  {
    nodes[i].openClose = NODE_UNLISTED;
    nodes[i].stat = NODE_UNUSED;
    nodes[i].parent = nullptr;
  }
  DumpMemory();
}

Node* GarbageCollector::Allocate(int x, int y)
{
  //Check index out of range error
  bool Error = x > (int)size - 1 || y > (int)size - 1 || x < 0 || y < 0;
  Debug::DebugPrint(Error, "Allocate: indexOut of range xy :%d %d,size: %d", x, y,size);

  if (Error)
    return nullptr;

  Node* allocate = &nodes[index(x,y)];
  Debug::DebugPrint(Error = (allocate->stat == NODE_USED), "Allocate: index is allocated", x, y, size);
  if (Error)
    return nullptr;

  ///////////////////////
  //Allocating
  //////////////////////
  allocate->stat = NODE_USED;
  //DumpMemory();
  return allocate;

}

bool GarbageCollector::Deallocate(int x, int y)
{
  if (x > (int)size || y > (int)size || x < 0 || y < 0)
    return false;

  Node* deallocate = &nodes[index(x, y)];
  if (deallocate->stat == NODE_USED)
  {
    deallocate->stat = NODE_UNUSED;
    //DumpMemory();
    return true;
  }
  else
  {
    return false;
  }
}

Node* GarbageCollector::Get(int x, int y)
{
  if (x > (int)size-1 || y >(int)size-1 || x < 0 || y < 0)
    return nullptr;

  Node* getThis = &nodes[index(x,y)];
  if (getThis->stat == NODE_USED)
  {
    return getThis;
  }
  else
  {
    return nullptr;
  }
}

Node* GarbageCollector::Get(int index)
{
  if (index > (unsigned)(size * size) - 1 || index < 0)
  {
    Debug::DebugPrint(true, "invalid index %d",index);
    return nullptr;
  }

  Node* getThis = &nodes[index];
  if (getThis->stat == NODE_USED)
  {
    return getThis;
  }
  else
  {
    return nullptr;
  }
}

gridPos GarbageCollector::GetGridPos(int index)
{
  if (index > (unsigned)(size * size) - 1 || index < 0)
  {
    Debug::DebugPrint(true, "invalid index %d", index);
    return gridPos(-1,-1);
  }

  int x, y;
  y = index / g_garbage->size;
  x = index % g_garbage->size;

  return gridPos(x, y);
}

Node* GarbageCollector::GetDetails(int x, int y)
{
  return &nodes[index(x, y)];
}

int GarbageCollector::index(int _x, int _y)
{
  unsigned x, y;
  x = _x;
  y = _y;

  if (x > (unsigned)size || y > (unsigned)size || x < 0 || y < 0)
    return -1;

  if (x > size)
    x = size;
  if (x < 0)
    x = 0;

  if (y > size)
    y = size;
  if (y < 0)
    y = size;


  return y * size + x;
}

void GarbageCollector::DumpMemory()
{
#ifdef DEBUG_GARBAGEDUMP
  for (int y = 0; y < size; ++y)
  {
    std::cout << std::endl;
    for (int x = 0; x < size; ++x)
    {
      std::string dumpThis;
      if(nodes[index(x, y)].stat == NODE_USED)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0x04);
      else
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0x08);


      nodes[index(x, y)].stat == NODE_USED ? dumpThis = "1" : dumpThis = "0";
      std::cout << dumpThis << "    ";
    }
  }
  std::cout << std::endl;
#endif
}

void GarbageCollector::DumpOpenClose()
{
#ifdef DEBUG_OPENCLOSEDUMP
  for (unsigned y = 0; y < size; ++y)
  {
    std::cout << std::endl;
    for (unsigned x = 0; x < size; ++x)
    {
      std::cout << nodes[index(x, y)].openClose << "   ";
    }
  }
  std::cout << std::endl;
#endif
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
// HELPER
////////////////////////////////////////////////////////////////////////////////////////////////////////
float HeuristicEucledean(Vec3 cur, Vec3 target) 
{
  Vec3 distVec = target - cur;
  return D3DXVec3Length(&distVec);
}

float HeuristicOctile(Vec3 cur, Vec3 target)
{
  float xDiff = std::fabs(target.x - cur.x);
  float yDiff = std::fabs(target.z - cur.z);
  float cmin = std::fmin(xDiff, yDiff);
  float cmax = std::fmax(xDiff, yDiff);

  return cmin * 1.41 + cmax - cmin;
}

float HeuristicChebyshev(Vec3 cur, Vec3 target)
{
  return std::fmax(std::fabs(target.x - cur.x), std::fabs(target.z - cur.z));
}

float HeuristicManhattan(Vec3 cur, Vec3 target)
{
  return std::fabs(target.x - cur.x) + std::fabs(target.z - cur.z);
}


bool operator<(const gridPos & lhs, const gridPos & rhs)// lhs = left-hand side
                                                         // rhs = right-hand side
{
  if (lhs.x != rhs.x)
  {
    return lhs.x < rhs.x;
  }
  else
  {
    return lhs.y < rhs.y;
  }
}

gridPos operator+(const gridPos & lhs, const gridPos & rhs)
{
  gridPos returnThis;

  returnThis.x = lhs.x + rhs.x;
  returnThis.y = lhs.y + rhs.y;

  if (returnThis.x > (unsigned)g_garbage->size - 1 || returnThis.x < 0)
    returnThis.x = -1;

  if (returnThis.y >(unsigned)g_garbage->size - 1 || returnThis.y < 0)
    returnThis.y = -1;

  return returnThis;
}


